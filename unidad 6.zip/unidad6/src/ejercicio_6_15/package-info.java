package ejercicio_6_15;

// Defina un método llamado hipotenusa que calcule la longitud de la hipotenusa
// de un triángulo rectángulo, cuando se proporcionen las longitudes de los otros dos lados. El método debe tomar dos
// argumentos de tipo double y devolver la hipotenusa como un valor double.
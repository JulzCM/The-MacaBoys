package ejercicio_6_35;

// El uso de las computadoras en la educación se conoce como instrucción
// asistida por computadora (CAI). Escriba un programa que ayude a un estudiante de escuela primaria a que aprenda
// a multiplicar. Use un objeto SecureRandom para producir dos enteros positivos de un dígito.
package ejercicio_6_22;

//(Conversiones de temperatura) Implemente los siguientes métodos enteros:
//a) El método centigrados que devuelve la equivalencia en grados Centígrados de una temperatura en grados
//Fahrenheit, mediante el cálculo
//centigrados = 5.0 / 9.0 * (fahrenheit – 32);
//b) El método fahrenheit que devuelve la equivalencia en grados Fahrenheit de una temperatura en grados
//Centígrados, con el cálculo fahrenheit = 9.0 / 5.0 * centigrados + 32;
//c) Utilice los métodos de los incisos (a) y (b) para escribir una aplicación que permita al usuario, ya sea escribir
//una temperatura en grados Fahrenheit y mostrar su equivalente en Centígrados, o escribir una
//temperatura en grados Centígrados y mostrar su equivalente en grados Fahrenheit.
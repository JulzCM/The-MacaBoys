package ejercicio_6_8;

//(Cargos por estacionamiento) Un estacionamiento cobra una cuota mínima de $2.00 por estacionarse hasta
//tres horas. El estacionamiento cobra $0.50 adicionales por cada hora o fracción que se pase de tres horas. El cargo
//máximo para cualquier periodo dado de 24 horas es de $10.00. Suponga que ningún auto se estaciona durante más
//de 24 horas seguidas. Escriba una aplicación que calcule y muestre los cargos por estacionamiento para cada cliente
//que se haya estacionado ayer. Debe introducir las horas de estacionamiento para cada cliente. El programa debe mostrar
//el cargo para el cliente actual así como calcular y mostrar el total corriente de los recibos de ayer. El programa debe
//utilizar el método calcularCargos para determinar el cargo para cada cliente.
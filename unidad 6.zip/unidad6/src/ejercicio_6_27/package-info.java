package ejercicio_6_27;

//Elmáximo común divisor (MCD) de dos enteros es el entero más grande que puede
//dividir de manera uniforme a cada uno de los dos números. Escriba un método llamado mcd que devuelva el máximo
//común divisor de dos enteros.

/**
 * 
 */
/**
 * @author Shuzaky
 *
 */
module FigurasGeometricas {
}